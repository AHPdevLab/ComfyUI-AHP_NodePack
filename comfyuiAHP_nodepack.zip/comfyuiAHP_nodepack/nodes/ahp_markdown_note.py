"""
AHP Markdown Note

A text note with an extended Markdown renderer, for notes in any language,
including right-to-left (RTL) languages such as Persian, Arabic and Hebrew.

Supported Markdown:
- CommonMark: headings, emphasis, links, images, lists, quotes, code blocks,
  horizontal rules, hard line breaks, escapes, entities
- GitHub Flavored Markdown: tables, ~~strikethrough~~, bare URLs become links
- Task lists:          - [x] done / - [ ] to do
- Footnotes:           text[^1] ... [^1]: note
- Definition lists:    Term / : definition
- Field lists:         :name: value
- Admonitions:         !!! note "Title" followed by an indented body
- Heading anchors:     every heading gets an id, so it can be linked to
- Math:                $inline$ and $$display$$ (LaTeX, shown as MathML)
- Subscript and superscript: H~2~O and x^2^
- Highlight:           ==marked text==
- Wikilinks:           [[Note]] and [[Note|shown text]], as in Obsidian
- Callouts:            > [!note] Title, then the body (Obsidian style)
- Front matter:        a leading --- block is read and hidden, as metadata

RTL handling: every block (paragraph, heading, list item, quote, table cell)
gets dir="auto", so the browser sets its direction from its first strong
character. Code and math always stay left-to-right.

Raw HTML is escaped and shown as text, not rendered. A shared workflow can
carry a note, and rendering raw HTML would let that note run scripts on the
machine that opens it.

The node has two outputs: the note's raw Markdown, and the rendered HTML.
The Markdown tab in the node uses the route below.

Licensed under the GNU General Public License v3.0. See LICENSE.
"""

import re
from html import escape

from aiohttp import web

# The node must appear in the node list even if its libraries are missing.
# Rendering then fails with a clear message, instead of the node vanishing.
_MISSING_LIBRARY = None
try:
    from markdown_it import MarkdownIt
    from mdit_py_plugins.admon import admon_plugin
    from mdit_py_plugins.anchors import anchors_plugin
    from mdit_py_plugins.deflist import deflist_plugin
    from mdit_py_plugins.dollarmath import dollarmath_plugin
    from mdit_py_plugins.field_list import fieldlist_plugin
    from mdit_py_plugins.footnote import footnote_plugin
    from mdit_py_plugins.front_matter import front_matter_plugin
    from mdit_py_plugins.subscript import sub_plugin
    from mdit_py_plugins.superscript import superscript_plugin
    from mdit_py_plugins.tasklists import tasklists_plugin
    from latex2mathml.converter import convert as latex_to_mathml
except ImportError as _error:
    _MISSING_LIBRARY = str(_error)

try:
    from server import PromptServer
except ImportError:  # Lets the module be imported outside ComfyUI, e.g. in tests
    PromptServer = None


ROUTE = "/ahp/markdown/render"
MAX_CHARS = 2_000_000  # Refuse absurdly large notes

# Block-level tokens that get dir="auto" so each block follows its own language.
AUTO_DIRECTION_TOKENS = {
    "paragraph_open",
    "heading_open",
    "list_item_open",
    "blockquote_open",
    "th_open",
    "td_open",
    "dt_open",
    "dd_open",
}

CALLOUT_FIRST_LINE = re.compile(r"^\[!([A-Za-z0-9_-]+)\][+-]?[ \t]*(.*)$")


# ------------------------------------------------------------- Math

def _math(latex, display):
    """Convert LaTeX to MathML. If the LaTeX is invalid, show it as plain code."""
    try:
        mathml = latex_to_mathml(latex.strip())
    except Exception:
        return f'<code class="ahp-math-error" dir="ltr">{escape(latex)}</code>'
    if display:
        mathml = mathml.replace('display="inline"', 'display="block"', 1)
    return mathml


def _render_math_inline(self, tokens, idx, options, env):
    return _math(tokens[idx].content, display=False)


def _render_math_block(self, tokens, idx, options, env):
    return f'<div class="ahp-math-block" dir="ltr">{_math(tokens[idx].content, display=True)}</div>\n'


# ------------------------------------------------------ Custom inline rules

def _highlight_rule(state, silent):
    """==marked text== becomes <mark>marked text</mark>."""
    src, pos = state.src, state.pos
    if src[pos:pos + 2] != "==":
        return False
    end = src.find("==", pos + 2)
    if end == -1 or end == pos + 2:
        return False
    if not silent:
        state.push("mark_open", "mark", 1)
        text = state.push("text", "", 0)
        text.content = src[pos + 2:end]
        state.push("mark_close", "mark", -1)
    state.pos = end + 2
    return True


def _wikilink_rule(state, silent):
    """[[Target]] or [[Target|shown text]], as in Obsidian."""
    src, pos = state.src, state.pos
    if src[pos:pos + 2] != "[[":
        return False
    end = src.find("]]", pos + 2)
    if end == -1:
        return False
    inner = src[pos + 2:end]
    if not inner.strip() or "\n" in inner:
        return False
    if not silent:
        target, _, alias = inner.partition("|")
        token = state.push("wikilink", "span", 0)
        token.content = (alias or target).strip()
        token.meta = {"target": target.strip()}
    state.pos = end + 2
    return True


def _render_wikilink(self, tokens, idx, options, env):
    token = tokens[idx]
    target = escape(token.meta.get("target", ""), quote=True)
    return f'<span class="ahp-wikilink" data-target="{target}">{escape(token.content)}</span>'


# -------------------------------------------------------- Custom core rule

def _callouts(state):
    """
    Turn Obsidian callouts into styled blockquotes.

    > [!warning] Title
    > body

    becomes a blockquote with the class ahp-callout-warning, and a bold title.
    Runs before inline parsing, while the text is still raw.
    """
    tokens = state.tokens
    for i, token in enumerate(tokens):
        if token.type != "blockquote_open" or i + 2 >= len(tokens):
            continue
        if tokens[i + 1].type != "paragraph_open" or tokens[i + 2].type != "inline":
            continue
        inline = tokens[i + 2]
        first, _, rest = inline.content.partition("\n")
        match = CALLOUT_FIRST_LINE.match(first.strip())
        if not match:
            continue
        kind = match.group(1).lower()
        title = match.group(2).strip() or kind.capitalize()
        token.attrSet("class", f"ahp-callout ahp-callout-{kind}")
        inline.content = f"**{title}**" + (f"\n{rest}" if rest else "")


# ------------------------------------------------------------- Renderer

def _mark_auto_direction(state):
    for token in state.tokens:
        if token.type in AUTO_DIRECTION_TOKENS:
            token.attrSet("dir", "auto")


def _render_front_matter(self, tokens, idx, options, env):
    return ""  # Metadata is read and hidden, as Obsidian hides properties in the note body


def _build_renderer():
    md = MarkdownIt("commonmark", {"html": False, "linkify": True, "typographer": False})
    md.enable(["table", "strikethrough", "linkify"])
    md.use(footnote_plugin)
    md.use(tasklists_plugin, enabled=True)
    md.use(deflist_plugin)
    md.use(fieldlist_plugin)
    md.use(admon_plugin)
    md.use(dollarmath_plugin, allow_space=True, double_inline=True)
    md.use(sub_plugin)
    md.use(superscript_plugin)
    md.use(anchors_plugin, min_level=1, max_level=6)
    md.use(front_matter_plugin)

    md.inline.ruler.before("emphasis", "ahp_highlight", _highlight_rule)
    md.inline.ruler.before("link", "ahp_wikilink", _wikilink_rule)

    md.add_render_rule("math_inline", _render_math_inline)
    md.add_render_rule("math_block", _render_math_block)
    md.add_render_rule("wikilink", _render_wikilink)
    md.add_render_rule("front_matter", _render_front_matter)

    md.core.ruler.before("inline", "ahp_callouts", _callouts)
    md.core.ruler.push("ahp_auto_direction", _mark_auto_direction)
    return md


INSTALL_HINT = (
    "The AHP Markdown Note needs some Python libraries that are not installed "
    f"in this ComfyUI environment ({_MISSING_LIBRARY}). Install them with: "
    "python -m pip install -r custom_nodes/comfyuiAHP_nodepack/requirements.txt "
    "then restart ComfyUI."
)

_RENDERER = _build_renderer() if _MISSING_LIBRARY is None else None


def render_markdown(text):
    """Return the note as an HTML fragment wrapped in a dir="auto" container."""
    if _RENDERER is None:
        raise RuntimeError(INSTALL_HINT)
    source = text or ""
    if len(source) > MAX_CHARS:
        raise ValueError(f"Note is too large ({len(source)} characters; the limit is {MAX_CHARS}).")
    return f'<div class="ahp-md" dir="auto">{_RENDERER.render(source)}</div>'


if PromptServer is not None:

    @PromptServer.instance.routes.post(ROUTE)
    async def ahp_render_markdown(request):
        """Live preview: takes {"text": ...} and returns {"html": ...}."""
        try:
            body = await request.json()
        except Exception:
            return web.json_response({"error": "Request body must be JSON."}, status=400)
        text = body.get("text", "") if isinstance(body, dict) else ""
        try:
            return web.json_response({"html": render_markdown(str(text))})
        except ValueError as error:
            return web.json_response({"error": str(error)}, status=413)
        except RuntimeError as error:
            return web.json_response({"error": str(error)}, status=500)


class AHPMarkdownNote:
    """Outputs the note as raw Markdown and as rendered HTML."""

    CATEGORY = "AHP/Text"
    FUNCTION = "make_note"
    RETURN_TYPES = ("STRING", "STRING")
    RETURN_NAMES = ("markdown", "html")

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {},
            "optional": {
                "text": ("STRING", {"default": "", "multiline": True}),
            },
        }

    def make_note(self, text=""):
        source = text or ""
        return (source, render_markdown(source))


NODE_CLASS_MAPPINGS = {
    "AHP_MarkdownNote": AHPMarkdownNote,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "AHP_MarkdownNote": "AHP Markdown Note",
}
